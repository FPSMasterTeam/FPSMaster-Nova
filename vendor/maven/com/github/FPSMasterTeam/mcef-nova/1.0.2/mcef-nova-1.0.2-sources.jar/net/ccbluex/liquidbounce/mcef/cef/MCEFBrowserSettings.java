/*
 * MCEF (Minecraft Chromium Embedded Framework)
 * Copyright (C) 2025 CCBlueX
 * Copyright (C) 2023 CinemaMod Group
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301
 * USA
 */

package net.ccbluex.liquidbounce.mcef.cef;

import org.cef.CefBrowserSettings;

public class MCEFBrowserSettings extends CefBrowserSettings {
    public MCEFBrowserSettings(int frameRate, boolean sharedTextureEnabled) {
        super();
        this.windowless_frame_rate = frameRate;
        // Zero-copy GPU acceleration (shared_texture_enabled) only works when the CEF message loop is
        // pumped on the render thread (no CefMessageLoopThread — macOS, or -Dmcef.pumpOnRenderThread):
        // onAcceleratedPaint then runs on the render thread with Minecraft's GL context current and
        // imports the handle synchronously, exactly like LiquidBounce's shipped setup.
        //
        // With the dedicated CEF thread, importing on a second shared GL context DID
        // record correct frames, but CEF's native accelerated OSR then delivers exactly ONE
        // onAcceleratedPaint and stalls (verified empirically; keyed-mutex, visibility and
        // texture-release theories all ruled out). So zero copy is gated to the render-thread pump and
        // browsers on the dedicated-thread setup fall back to the CPU onPaint path.
        boolean canZeroCopy = CefHelper.getMessageLoopThread() == null;
        this.shared_texture_enabled = sharedTextureEnabled && canZeroCopy;
    }
}
